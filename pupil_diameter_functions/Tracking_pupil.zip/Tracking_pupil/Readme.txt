Main file: main.m

Feel free to change the code and insert in your project. Please do not forget cite the source:

Barrag�n, D. "Tracking pupil using image processing", Retrieved January 29, 2015, from http://www.matpic.com.